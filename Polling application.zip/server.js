const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = process.env.PORT || 3000; // Use the specified port or default to 3000

// Middlewares
app.use(bodyParser.json());

// Include your route files
const authRoutes = require('./routes/authRoutes');
const pollRoutes = require('./routes/pollRoutes');
const userRoutes = require('./routes/userRoutes');

// Use the routes
app.use('/auth', authRoutes); // Authentication routes
app.use('/polls', pollRoutes); // Poll management routes
app.use('/users', userRoutes); // User management routes

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
module.exports = app; // Export the app instance
