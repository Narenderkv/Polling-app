const jwt = require('jsonwebtoken');

// Define your JWT secret key (this should be kept secret)
const secretKey = 'your-secret-key';

// Function to create a JWT token
function createToken(payload) {
    return jwt.sign(payload, secretKey, { expiresIn: '1h' }); // Token expires in 1 hour
}

// Middleware to verify JWT token in requests
function verifyToken(req, res, next) {
    const token = req.header('Authorization'); // Assuming the token is sent in the 'Authorization' header

    if (!token) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    try {
        const decoded = jwt.verify(token, secretKey);
        req.user = decoded; // Attach the decoded user to the request object
        next();
    } catch (error) {
        return res.status(403).json({ message: 'Invalid token' });
    }
}

module.exports = {
    createToken,
    verifyToken, secretKey
};
