const request = require('supertest');
const app = require('../server'); // Import your Express app instance
const chai = require('chai');
const expect = chai.expect;

describe('Polling Endpoints', () => {
    let authToken;

    // Login the test user and save the JWT token (if not already done in authentication tests)
    before((done) => {
        request(app)
            .post('/auth/login')
            .send({ username: 'testuser', password: 'testpassword' })
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                authToken = res.body.token;
                done();
            });
    });

    // Create a new poll (requires authentication)
    it('should create a new poll', (done) => {
        request(app)
            .post('/polls/create')
            .set('Authorization', authToken)
            .send({
                title: 'Sample Poll',
                description: 'This is a sample poll.',
                options: ['Option A', 'Option B', 'Option C'],
            })
            .expect(201)
            .end((err, res) => {
                if (err) return done(err);
                done();
            });
    });

    // List all polls
    it('should list all available polls', (done) => {
        request(app)
            .get('/polls/list')
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                expect(res.body).to.be.an('array');
                done();
            });
    });

    // Vote on a poll (requires authentication)
    it('should allow a user to vote on a poll', (done) => {
        request(app)
            .post('/polls/vote')
            .set('Authorization', authToken)
            .send({ pollId: 1, optionId: 2 }) // Replace with actual poll and option IDs
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                done();
            });
    });
});
