const jwt = require('jsonwebtoken');
const { verifyToken } = require('../config/jwt'); // Import JWT configuration
const { secretKey } = require('../config/jwt'); // Import JWT configuration

function authenticateUser(req, res, next) {
    const token = req.header('Authorization');

    if (!token) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    try {
        const tokenValue = token.split(' ')[1]; // Extract the actual token

        // Verify and decode the token using the secret key from the JWT configuration
        const decoded = jwt.verify(tokenValue, secretKey);

        // Attach the decoded user to the request object for further use in controllers
        req.user = decoded;

        next();
    } catch (error) {
        console.error('Token Verification Error:', error);
        return res.status(403).json({ message: 'Invalid token' });
    }
}

module.exports = {
    authenticateUser,
};
