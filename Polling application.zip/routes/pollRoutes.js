const express = require('express');
const router = express.Router();
const pollController = require('../controllers/pollController');
const { authenticateUser } = require('../middlewares/authMiddleware');

// Create a new poll (requires authentication)
router.post('/create', authenticateUser, pollController.createPoll);

// Get a list of all available polls
router.get('/list', pollController.getAllPolls);

// Vote on a poll (requires authentication)
router.post('/vote', authenticateUser, pollController.votePoll);

module.exports = router;
