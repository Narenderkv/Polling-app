const db = require('../config/db'); // Assuming you have a db.js configuration file
// Create a new poll
exports.createPoll = async (req, res) => {

    try {
        const { title, description, options } = req.body;
        // Insert the poll into the database
        const [result] = await db.query('INSERT INTO polls (title, description) VALUES (?, ?)', [title, description]);
        const pollId = result.insertId;

        // Insert poll options into the database
        const optionValues = options.map((option) => [pollId, option]);
        await db.query('INSERT INTO poll_options (poll_id, option_text) VALUES ?', [optionValues]);

        res.status(201).json({ message: 'Poll created successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};

// Get a list of all available polls
exports.getAllPolls = async (req, res) => {
    try {
        const [polls] = await db.query('SELECT * FROM polls');
        res.status(200).json(polls);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};

// Vote on a poll
exports.votePoll = async (req, res) => {
    try {
        const { pollId, optionId } = req.body;

        // Check if the poll exists
        const [poll] = await db.query('SELECT * FROM polls WHERE id = ?', [pollId]);

        if (poll.length === 0) {
            return res.status(404).json({ message: 'Poll not found' });
        }

        // Check if the option exists
        const [option] = await db.query('SELECT * FROM poll_options WHERE id = ? AND poll_id = ?', [optionId, pollId]);

        if (option.length === 0) {
            return res.status(404).json({ message: 'Poll option not found' });
        }

        // Insert the vote into the database
        await db.query('INSERT INTO poll_votes (poll_id, option_id, user_id) VALUES (?, ?, ?)', [
            pollId,
            optionId,
            req.user.userId, // Assuming you have user authentication middleware
        ]);

        res.status(200).json({ message: 'Vote recorded successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
