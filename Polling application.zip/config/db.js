
const mysql = require('mysql2');

// Create a connection pool
const pool = mysql.createPool({
    host: 'localhost', // Replace with your MySQL server host
    user: 'root', // Replace with your MySQL username
    password: 'root', // Replace with your MySQL password
    database: 'polling_app_db',
    waitForConnections: true,
    connectionLimit: 10, // Adjust this limit according to your needs
    queueLimit: 0,
});

// Export the pool for use in other parts of the application
module.exports = pool.promise();

