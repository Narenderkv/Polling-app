const request = require('supertest');
const app = require('../server'); // Import your Express app instance
const chai = require('chai');
const expect = chai.expect;

describe('Authentication Endpoints', () => {
    let authToken;

    // Register a test user
    it('should register a new user', (done) => {
        request(app)
            .post('/auth/register')
            .send({ username: 'testuser', password: 'testpassword' })
            .expect(201)
            .end((err, res) => {
                if (err) return done(err);
                done();
            });
    });

    // Login the test user and save the JWT token
    it('should login an existing user and return a JWT token', (done) => {
        request(app)
            .post('/auth/login')
            .send({ username: 'testuser', password: 'testpassword' })
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                authToken = res.body.token;
                done();
            });
    });

    // Access a protected route using the JWT token
    it('should access a protected route with a valid JWT token', (done) => {
        request(app)
            .get('/protected-route')
            .set('Authorization', authToken)
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                done();
            });
    });
});
