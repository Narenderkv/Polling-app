const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticateUser } = require('../middlewares/authMiddleware');

// Get user details (requires authentication)
router.get('/:userId', authenticateUser, userController.getUserDetails);

// Get user's voting history (requires authentication)
router.get('/:userId/voting-history', authenticateUser, userController.getUserVotingHistory);

module.exports = router;
