const db = require('../config/db'); // Assuming you have a db.js configuration file

// Get user details
exports.getUserDetails = async (req, res) => {
    try {
        const { userId } = req.params;

        // Fetch user details from the database
        const [user] = await db.query('SELECT id, username FROM users WHERE id = ?', [userId]);

        if (user.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json(user[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};

// Get user's voting history
exports.getUserVotingHistory = async (req, res) => {
    try {
        const { userId } = req.params;

        // Fetch the polls the user has voted in from the database
        const [votingHistory] = await db.query('SELECT polls.id, polls.title, poll_options.option_text FROM poll_votes \
      JOIN polls ON poll_votes.poll_id = polls.id \
      JOIN poll_options ON poll_votes.option_id = poll_options.id \
      WHERE poll_votes.user_id = ?', [userId]);

        res.status(200).json(votingHistory);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
